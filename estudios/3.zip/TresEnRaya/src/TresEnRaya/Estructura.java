package TresEnRaya;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Estructura extends Frame implements ActionListener {
	
	
	Label resultado = new Label ("");
	Button[][] grid_botones = new Button[3][3];
	Button init = new Button("COMENZAR");
	Checkbox cb1 = new Checkbox("Jugador VS Jugador");
	Checkbox cb2 = new Checkbox("Jugador VS M�quina");
	Panel panel_grid_botones = new Panel();
	Panel panel_checkboxes = new Panel();
	Panel panel_este = new Panel();
	int contador = 1;
	boolean jganadorX = false;
	boolean jganadorO = false;
	
	static Estructura e1 = new Estructura();
	
	
	public static void main(String[] args){
		e1.setVisible(true);
	}
	
	public Estructura(){
		
		this.setTitle("Tres en raya");
		this.setSize(500, 400);
		this.setLayout(new BorderLayout());
		
		//Listener para cerrar la app con la X
		this.addWindowListener(new WindowEventClose());
		
		//Creaci�n de panel para los botones.
		panel_grid_botones.setBackground(Color.blue);
		panel_grid_botones.setLayout(new GridLayout(3,3));
		//Creaci�n de botones asignados a posiciones de un array.
		
		for(int i=0;i<3; i++){
			for(int j=0;j<3;j++)
			{
			grid_botones[i][j]=new Button();
			grid_botones[i][j].setLabel("");
			grid_botones[i][j].addActionListener(this);
			//	casillas[i][j].addActionListener(this);
			//	casillas[i][j].addMouseListener(new EscuchadorDeRaton());
			//	casillas[i][j].addMouseListener(this);
			panel_grid_botones.add(grid_botones[i][j]);
			}
		}
		panel_grid_botones.setEnabled(false);
		
		//Add checkboxes al panel
		panel_checkboxes.setLayout(new GridLayout(4,0));
		panel_checkboxes.add(cb1 );
		panel_checkboxes.add(cb2);
		
		//Panel para posicionar el panel de  checkboxes.
		panel_este.setLayout(new GridLayout(3,0));
		panel_este.setBackground(Color.gray);
		panel_este.add(panel_checkboxes);
		
		//Label para el resultado.
		panel_este.add(resultado);
		
		//Boton reiniciar
		Panel pboton = new Panel();
		pboton.setLayout(new FlowLayout());
		init.addActionListener(this);
		pboton.add(init);
		panel_este.add(pboton);
		
		//Inserci�n de panels al frame
		this.add(panel_este, BorderLayout.EAST);
		this.add(panel_grid_botones, BorderLayout.CENTER);
		
		
	}
	//METODO PARA LIMPIAR LOS LABELS DE LOS BOTONES.
	public void reiniciarGridBotones(){
		for (int i=0; i<3; i++){
			for (int j=0; j<3; j++){
				grid_botones[i][j].setLabel("");
				grid_botones[i][j].setEnabled(true);
			}
		}
	}
	//METODO PARA REINICIAR LAS OPCIONES DE LAS CHECKBOXES
	public void reiniciarCheckboxes(){
		cb1.setState(false);
		cb2.setState(false);
		cb1.setEnabled(true);
		cb2.setEnabled(true);
		
	}
	
	//METODO QUE RECOGE LA ENTRADA DE INFORMACION DEL RATON.
		public void actionPerformed(ActionEvent ev) {
			
			String label_boton = ((Button)ev.getSource()).getLabel();
			inteligenciaMaquina();
			if (label_boton == "COMENZAR"){
				if (cb1.getState()==false & cb2.getState()==false){
					e1.resultado.setText("ELIGE UN MODO");
					panel_grid_botones.setEnabled(false);
				}
				if (cb1.getState()==true & cb2.getState()==true){
					e1.resultado.setText("ELIGE SOLO 1!!");
					reiniciarCheckboxes();
					panel_grid_botones.setEnabled(false);
				}else{
					e1.init.setLabel("REINICIAR");
					cb1.setEnabled(false);
					cb2.setEnabled(false);
					panel_grid_botones.setEnabled(true);
				}
			}
			else{
				if (label_boton == "REINICIAR"){
					e1.reiniciar();
				}else{
					if (cb1.getState()==true){
					e1.jugadorVSJugador(ev);
					}
					if (cb2.getState()==true){
						e1.jugadorVSMaquina(ev);
					}	
				}	
			}	
		}	
		//METODO PARA REINICIAR EL JUEGO
		public void reiniciar(){
			e1.reiniciarCheckboxes();
			e1.reiniciarGridBotones();
			e1.resultado.setText("REINICIADO!");
			e1.init.setLabel("COMENZAR");
			contador = 1;
			panel_grid_botones.setEnabled(false);
			
			
		}
		public void jugadorVSJugador(ActionEvent ev2){
			//Jugador impar
			if (contador%2==1){
				((Button) ev2.getSource()).setLabel("X");
				((Button) ev2.getSource()).setEnabled(false);
				contador++;
				e1.resultado.setText("TURNO PLAYER 2");
				e1.hayGanador();
				//Jugador par
			}else{
				((Button)ev2.getSource()).setLabel("O");
				((Button) ev2.getSource()).setEnabled(false);
				contador++;
				e1.resultado.setText("TURNO PLAYER 1");
				e1.hayGanador();
			}
		}
		//METODO JUGADOR VS MAQUINA CON ALEATORIOS INT PARA POSICIONES
		public void jugadorVSMaquina(ActionEvent ev3){
			if (contador%2==1){
				((Button) ev3.getSource()).setLabel("X");
				((Button) ev3.getSource()).setEnabled(false);
				contador++;
				e1.resultado.setText("TURNO MAQUINA");
				if (e1.hayGanador()!=true){
					//COMPRUEBA QUE EL JUGADOR 1 NO ESTE A PUNTO DE GANAR
					if (inteligenciaMaquina()){
						contador++;
						e1.resultado.setText("TURNO PLAYER 1");
					}else{
						int x = numerosAleatorios();
						int y = numerosAleatorios();
						//SIGUE BUSCANDO HUECO VACIO PARA RELLENAR
						while(grid_botones[x][y].getLabel()!=""){
							x = numerosAleatorios();
							y = numerosAleatorios();
						}
						e1.grid_botones[x][y].setLabel("O");
						e1.grid_botones[x][y].setEnabled(false);
						contador++;
						e1.resultado.setText("TURNO PLAYER 1");
						e1.hayGanador();
					}
				}
			}
		}
		//METODO PARA QUE LA MAQUINA PUEDA JUGAR ALEATORIAMENTE
		public int numerosAleatorios(){
			int x;
			x= (int)Math.floor(Math.random()*3);
			return x;
		}
		//METODO PARA JUNTAR LOS POSIBLES CASOS DE VICTORIA
		public boolean hayGanador(){
				e1.ganadorFilasYColumnas();	
				e1.ganadorDiagonales();
				if (jganadorX & jganadorO == false){
					e1.resultado.setText("PLAYER 1 WIN!");
					jganadorX = false;
					panel_grid_botones.setEnabled(false);
					return true;
				}
				if(jganadorO & jganadorX ==false){
					e1.resultado.setText("PLAYER 2 WIN!");
					jganadorO=false;
					panel_grid_botones.setEnabled(false);
					return true;
				}
				if (contador ==10){
					e1.resultado.setText("EMPATE!");
					return true;
				}
				return false;
		}
		//METODO COMPROBACI�N FILAS Y COLUMNAS
		public void ganadorFilasYColumnas(){
			
			for(int inicio = 0; inicio<=2; inicio++){
				int contadorfX = 0, contadorfO = 0;
				int contadorcX = 0, contadorcO = 0;
				for(int fin = 0; fin<=2; fin++){
					//COMPROBADOR DE FILAS
					if (grid_botones[inicio][fin].getLabel()=="X"){
						contadorfX++;
					}else{
						if (grid_botones[inicio][fin].getLabel()=="O"){
							contadorfO++;
						}
					}
					//COMPROBACION DE COLUMNAS
					if (grid_botones[fin][inicio].getLabel()=="X"){
						contadorcX++;
					}else{
						if (grid_botones[fin][inicio].getLabel()=="O"){
							contadorcO++;
						}
					}
				}
				//COMPROBACION GANADOR				
				if (contadorfX == 3 | contadorcX == 3){
					jganadorX =true;
					break;
				}else{
					if (contadorfO == 3 | contadorcO == 3){
						jganadorO = true;
						break;
					}
				}
			}
		}
		//METODO COMPRABACION DE DIAGONALES
		public void ganadorDiagonales(){
			if(grid_botones[0][0].getLabel()=="X" && grid_botones[1][1].getLabel()=="X" && grid_botones[2][2].getLabel()=="X"){
				jganadorX = true;
			}else{
				if(grid_botones[0][0].getLabel()=="O" && grid_botones[1][1].getLabel()=="O" && grid_botones[2][2].getLabel()=="O"){
					jganadorO = true;
				}
			}
			if(grid_botones[0][2].getLabel()=="X" && grid_botones[1][1].getLabel()=="X" && grid_botones[2][0].getLabel()=="X"){
				jganadorX=true;
			}else{
				if(grid_botones[0][2].getLabel()=="O" && grid_botones[1][1].getLabel()=="O" && grid_botones[2][0].getLabel()=="O"){
					jganadorO=true;
				}
			}
		}
		//METODO PARA QUE LA MAQUINA JUEGUE EVITANDO QUE GANE EL JUGADOR
		public boolean inteligenciaMaquina(){
			for (int j=0; j<=2; j++){
					//CONDICIONES PARA EVITAR GANAR EN LAS FILAS
					if ( grid_botones[j][0].getLabel()=="X" & grid_botones[j][1].getLabel()=="X" & grid_botones[j][2].getLabel() == ""){
						grid_botones[j][2].setLabel("O");
						grid_botones[j][2].setEnabled(false);
						return true;
					}
					if ( grid_botones[j][1].getLabel()=="X" & grid_botones[j][2].getLabel()=="X" & grid_botones[j][0].getLabel() == ""){
						grid_botones[j][0].setLabel("O");
						grid_botones[j][0].setEnabled(false);
						return true;
					}
					if ( grid_botones[j][0].getLabel()=="X" & grid_botones[j][2].getLabel()=="X" & grid_botones[j][1].getLabel() == ""){
						grid_botones[j][1].setLabel("O");
						grid_botones[j][1].setEnabled(false);
						return true;
					}
					//CONDICIONES PARA EVITAR GANAR EN LAS COLUMNAS
					if ( grid_botones[0][j].getLabel()=="X" & grid_botones[1][j].getLabel()=="X" & grid_botones[2][j].getLabel() == ""){
						grid_botones[2][j].setLabel("O");
						grid_botones[2][j].setEnabled(false);
						return true;
					}
					if ( grid_botones[0][j].getLabel()=="X" & grid_botones[2][j].getLabel()=="X" & grid_botones[1][j].getLabel() == ""){
						grid_botones[1][j].setLabel("O");
						grid_botones[1][j].setEnabled(false);
						return true;
					}
					if ( grid_botones[1][j].getLabel()=="X" & grid_botones[2][j].getLabel()=="X" & grid_botones[0][j].getLabel() == ""){
						grid_botones[0][j].setLabel("O");
						grid_botones[0][j].setEnabled(false);
						return true;
					}
			}
			//CONDICIONES EVITAR GANAR DIAGONAL DE 00 HACIA 22
			if ( grid_botones[0][0].getLabel()=="X" & grid_botones[1][1].getLabel()=="X" & grid_botones[2][2].getLabel() == ""){
				grid_botones[2][2].setLabel("O");
				grid_botones[2][2].setEnabled(false);
				return true;
			}
			if ( grid_botones[0][0].getLabel()=="X" & grid_botones[2][2].getLabel()=="X" & grid_botones[1][1].getLabel() == ""){
				grid_botones[1][1].setLabel("O");
				grid_botones[1][1].setEnabled(false);
				return true;
			}
			if ( grid_botones[1][1].getLabel()=="X" & grid_botones[2][2].getLabel()=="X" & grid_botones[0][0].getLabel() == ""){
				grid_botones[0][0].setLabel("O");
				grid_botones[0][0].setEnabled(false);
				return true;
			}
			//CONDICION EVITAR GANAR DIAGONAL DE 20 HACIA 02
			if ( grid_botones[2][0].getLabel()=="X" & grid_botones[1][1].getLabel()=="X" & grid_botones[0][2].getLabel() == ""){
				grid_botones[0][2].setLabel("O");
				grid_botones[0][2].setEnabled(false);
				return true;
			}
			if ( grid_botones[2][0].getLabel()=="X" & grid_botones[0][2].getLabel()=="X" & grid_botones[1][1].getLabel() == ""){
				grid_botones[1][1].setLabel("O");
				grid_botones[1][1].setEnabled(false);
				return true;
			}
			if ( grid_botones[0][2].getLabel()=="X" & grid_botones[1][1].getLabel()=="X" & grid_botones[2][0].getLabel() == ""){
				grid_botones[2][0].setLabel("O");
				grid_botones[2][0].setEnabled(false);
				return true;
			}
			return false;
		}
			
}
