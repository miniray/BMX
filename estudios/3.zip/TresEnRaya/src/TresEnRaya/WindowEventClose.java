package TresEnRaya;
import java.awt.event.*;

public class WindowEventClose extends WindowAdapter {
	
	public void windowClosing( WindowEvent ev){
		
		System.exit(0);
	}

}
